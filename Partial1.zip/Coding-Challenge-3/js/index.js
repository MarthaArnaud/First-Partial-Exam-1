console.log("se cargo bien");

function getFizz(){
	var getButton= document.getElementById("submitBtn");
	getButton.addEventListener("click",(event)=>{
		event.preventDefault();
		var text = document.querySelector(".fizzBuzzNumber").value;
		var newElement= document.querySelector(".resultsSection");
		if(Number(text)%15==0){
			newElement.innerHTML+=" "+`<span class="delete">FizzBuzz</span>`+ " ";
			text+= " ";
			
		}
		else if(Number(text)%5==0){
			newElement.innerHTML+=" "+`<span class="delete">Buzz</span>`+ " ";
			text+= " ";
		}
		else if(Number(text)%3==0){
			newElement.innerHTML+=" "+`<span class="delete">Fizz</span>`+ " ";
			text+= " ";
		}
		else{
		newElement.innerHTML+=" "+`<span class="delete">${text}</span>`+ " ";
		text+= " ";
	}
	})
}

function deleteElement(){
	var element= document.querySelector(".resultsSection");
	element.addEventListener("click", (event)=>{
		if(event.target.matches(".delete")){
			event.target.remove();
		}
	})
}

getFizz();

deleteElement();